# CryptocurrencyQuotesLatestResponseModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Data** | [***map[string]CryptocurrencyQuotesLatestCryptocurrencyObject**](map.md) |  | [default to null]
**Status** | [***ApiStatusObject**](api-status-object.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

