# CryptocurrencyInfoResponseModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Data** | [***map[string]CryptocurrenciesInfoCryptocurrencyObject**](map.md) |  | [optional] [default to null]
**Status** | [***ApiStatusObject**](api-status-object.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

