# HttpStatus429ErrorObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | [***ErrorStatus**](error-status.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

