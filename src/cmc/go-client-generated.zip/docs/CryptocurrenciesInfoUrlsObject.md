# CryptocurrenciesInfoUrlsObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Website** | [***[]string**](array.md) |  | [default to null]
**TechnicalDoc** | [***[]string**](array.md) |  | [default to null]
**Explorer** | [***[]string**](array.md) |  | [default to null]
**SourceCode** | [***[]string**](array.md) |  | [default to null]
**MessageBoard** | [***[]string**](array.md) |  | [default to null]
**Chat** | [***[]string**](array.md) |  | [default to null]
**Announcement** | [***[]string**](array.md) |  | [default to null]
**Reddit** | [***[]string**](array.md) |  | [default to null]
**Twitter** | [***[]string**](array.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

